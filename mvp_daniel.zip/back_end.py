import sqlite3
from flask import Flask, jsonify, request
from flasgger import Swagger
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
dbname = 'database.db'
swagger = Swagger(app)

def data_base_connection():
    conn = sqlite3.connect(dbname)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/categoria', methods=['GET'])
def get_categoria():
    """
    Endpoint para obter a lista de categorias
    ---
    responses:
      200:
        description: Lista de categorias obtida com sucesso
        schema:
          type: array
          items:
            type: object
            properties:
              id:
                type: integer
                description: ID da categoria
              name:
                type: string
                description: Nome da categoria
              description:
                type: string
                description: Descrição da categoria
    """
    conn = data_base_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Categoria")
    rows = cursor.fetchall()
    categories = [dict(row) for row in rows]
    conn.close()
    return jsonify(categories)

@app.route('/login', methods=['POST'])
def login():
    """
    Autenticação de usuário
    ---
    tags:
      - Autenticação
    consumes:
      - application/json
    parameters:
      - in: body
        name: credenciais
        required: true
        schema:
          type: object
          required: [usuario, senha]
          properties:
            usuario:
              type: string
              description: Nome de usuário (corresponde a Usuario.Nome_usuario)
              example: "daniel"
            senha:
              type: string
              description: Senha do usuário (corresponde a Usuario.senha)
              example: "123456"
    responses:
      200:
        description: Login bem-sucedido
        schema:
          type: object
          properties:
            user_id:
              type: integer
            usuario:
              type: string
            message:
              type: string
      401:
        description: Credenciais inválidas
        schema:
          type: object
          properties:
            error:
              type: string
    """
    data = request.get_json(silent=True) or {}
    usuario = data.get('usuario')
    senha = data.get('senha')

    if not usuario or not senha:
        return jsonify({"error": "Informe usuario e senha"}), 400

    conn = data_base_connection()
    cur = conn.cursor()
    # Tabela: Usuario | Campos: Nome_usuario, senha
    cur.execute("""
        SELECT rowid AS id, Nome_usuario
        FROM Usuario
        WHERE Nome_usuario = ? AND senha = ?
        LIMIT 1
    """, (usuario, senha))
    row = cur.fetchone()
    conn.close()

    if not row:
        return jsonify({"error": "Credenciais inválidas"}), 401

    return jsonify({
        "user_id": row["id"],
        "usuario": row["Nome_usuario"],
        "message": "Login bem-sucedido"
    }), 200

# -------------------------------
# GET /tarefas  (lista bruta)
# -------------------------------
@app.route('/tarefas', methods=['GET'])
def get_tarefas():
    """
    Lista todas as tarefas
    ---
    tags:
      - Tarefas
    responses:
      200:
        description: Lista de tarefas obtida com sucesso
        schema:
          type: array
          items:
            type: object
            properties:
              id:
                type: integer
              titulo:
                type: string
              descricao:
                type: string
              fk_status:
                type: string
                description: Status usado no Kanban
    """
    conn = data_base_connection()
    cur = conn.cursor()
    # Tabela: Tarefas | Campos mínimos esperados: id, titulo, descricao, fk_status
    cur.execute("SELECT * FROM Tarefas")
    rows = cur.fetchall()
    tarefas = [dict(r) for r in rows]
    conn.close()
    return jsonify(tarefas), 200

if __name__ == '__main__':
    app.run(debug=True)